// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SmaccTransition = require('./SmaccTransition.js');
let SmaccOrthogonal = require('./SmaccOrthogonal.js');
let SmaccLogicUnit = require('./SmaccLogicUnit.js');

//-----------------------------------------------------------

class SmaccState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.index = null;
      this.name = null;
      this.children_states = null;
      this.level = null;
      this.transitions = null;
      this.orthogonals = null;
      this.logic_units = null;
    }
    else {
      if (initObj.hasOwnProperty('index')) {
        this.index = initObj.index
      }
      else {
        this.index = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('children_states')) {
        this.children_states = initObj.children_states
      }
      else {
        this.children_states = [];
      }
      if (initObj.hasOwnProperty('level')) {
        this.level = initObj.level
      }
      else {
        this.level = 0;
      }
      if (initObj.hasOwnProperty('transitions')) {
        this.transitions = initObj.transitions
      }
      else {
        this.transitions = [];
      }
      if (initObj.hasOwnProperty('orthogonals')) {
        this.orthogonals = initObj.orthogonals
      }
      else {
        this.orthogonals = [];
      }
      if (initObj.hasOwnProperty('logic_units')) {
        this.logic_units = initObj.logic_units
      }
      else {
        this.logic_units = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccState
    // Serialize message field [index]
    bufferOffset = _serializer.int32(obj.index, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [children_states]
    bufferOffset = _arraySerializer.string(obj.children_states, buffer, bufferOffset, null);
    // Serialize message field [level]
    bufferOffset = _serializer.int8(obj.level, buffer, bufferOffset);
    // Serialize message field [transitions]
    // Serialize the length for message field [transitions]
    bufferOffset = _serializer.uint32(obj.transitions.length, buffer, bufferOffset);
    obj.transitions.forEach((val) => {
      bufferOffset = SmaccTransition.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [orthogonals]
    // Serialize the length for message field [orthogonals]
    bufferOffset = _serializer.uint32(obj.orthogonals.length, buffer, bufferOffset);
    obj.orthogonals.forEach((val) => {
      bufferOffset = SmaccOrthogonal.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [logic_units]
    // Serialize the length for message field [logic_units]
    bufferOffset = _serializer.uint32(obj.logic_units.length, buffer, bufferOffset);
    obj.logic_units.forEach((val) => {
      bufferOffset = SmaccLogicUnit.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccState
    let len;
    let data = new SmaccState(null);
    // Deserialize message field [index]
    data.index = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [children_states]
    data.children_states = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [level]
    data.level = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [transitions]
    // Deserialize array length for message field [transitions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.transitions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.transitions[i] = SmaccTransition.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [orthogonals]
    // Deserialize array length for message field [orthogonals]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.orthogonals = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.orthogonals[i] = SmaccOrthogonal.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [logic_units]
    // Deserialize array length for message field [logic_units]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.logic_units = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.logic_units[i] = SmaccLogicUnit.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    object.children_states.forEach((val) => {
      length += 4 + val.length;
    });
    object.transitions.forEach((val) => {
      length += SmaccTransition.getMessageSize(val);
    });
    object.orthogonals.forEach((val) => {
      length += SmaccOrthogonal.getMessageSize(val);
    });
    object.logic_units.forEach((val) => {
      length += SmaccLogicUnit.getMessageSize(val);
    });
    return length + 25;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8e558ce98869ff567d3e2c9c93b563f0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 index
    string name
    string[] children_states
    int8 level
    smacc_msgs/SmaccTransition[] transitions
    smacc_msgs/SmaccOrthogonal[] orthogonals
    smacc_msgs/SmaccLogicUnit[] logic_units
    
    
    ================================================================================
    MSG: smacc_msgs/SmaccTransition
    int32 index
    string transition_name
    string transition_type
    string destiny_state_name
    string source_state_name
    bool history_node
    smacc_msgs/SmaccEvent event
    
    ================================================================================
    MSG: smacc_msgs/SmaccEvent
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    ================================================================================
    MSG: smacc_msgs/SmaccOrthogonal
    string name
    string[] substate_behavior_names
    string[] client_names
    ================================================================================
    MSG: smacc_msgs/SmaccLogicUnit
    int32 index
    string type_name
    string object_tag
    
    smacc_msgs/SmaccEvent[] event_sources
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccState(null);
    if (msg.index !== undefined) {
      resolved.index = msg.index;
    }
    else {
      resolved.index = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.children_states !== undefined) {
      resolved.children_states = msg.children_states;
    }
    else {
      resolved.children_states = []
    }

    if (msg.level !== undefined) {
      resolved.level = msg.level;
    }
    else {
      resolved.level = 0
    }

    if (msg.transitions !== undefined) {
      resolved.transitions = new Array(msg.transitions.length);
      for (let i = 0; i < resolved.transitions.length; ++i) {
        resolved.transitions[i] = SmaccTransition.Resolve(msg.transitions[i]);
      }
    }
    else {
      resolved.transitions = []
    }

    if (msg.orthogonals !== undefined) {
      resolved.orthogonals = new Array(msg.orthogonals.length);
      for (let i = 0; i < resolved.orthogonals.length; ++i) {
        resolved.orthogonals[i] = SmaccOrthogonal.Resolve(msg.orthogonals[i]);
      }
    }
    else {
      resolved.orthogonals = []
    }

    if (msg.logic_units !== undefined) {
      resolved.logic_units = new Array(msg.logic_units.length);
      for (let i = 0; i < resolved.logic_units.length; ++i) {
        resolved.logic_units[i] = SmaccLogicUnit.Resolve(msg.logic_units[i]);
      }
    }
    else {
      resolved.logic_units = []
    }

    return resolved;
    }
};

module.exports = SmaccState;
