// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SmaccEvent {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.event_type = null;
      this.event_object_tag = null;
      this.event_source = null;
      this.label = null;
    }
    else {
      if (initObj.hasOwnProperty('event_type')) {
        this.event_type = initObj.event_type
      }
      else {
        this.event_type = '';
      }
      if (initObj.hasOwnProperty('event_object_tag')) {
        this.event_object_tag = initObj.event_object_tag
      }
      else {
        this.event_object_tag = '';
      }
      if (initObj.hasOwnProperty('event_source')) {
        this.event_source = initObj.event_source
      }
      else {
        this.event_source = '';
      }
      if (initObj.hasOwnProperty('label')) {
        this.label = initObj.label
      }
      else {
        this.label = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccEvent
    // Serialize message field [event_type]
    bufferOffset = _serializer.string(obj.event_type, buffer, bufferOffset);
    // Serialize message field [event_object_tag]
    bufferOffset = _serializer.string(obj.event_object_tag, buffer, bufferOffset);
    // Serialize message field [event_source]
    bufferOffset = _serializer.string(obj.event_source, buffer, bufferOffset);
    // Serialize message field [label]
    bufferOffset = _serializer.string(obj.label, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccEvent
    let len;
    let data = new SmaccEvent(null);
    // Deserialize message field [event_type]
    data.event_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [event_object_tag]
    data.event_object_tag = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [event_source]
    data.event_source = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [label]
    data.label = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.event_type.length;
    length += object.event_object_tag.length;
    length += object.event_source.length;
    length += object.label.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccEvent';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3251016be597911e390bd8a527fce6ab';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccEvent(null);
    if (msg.event_type !== undefined) {
      resolved.event_type = msg.event_type;
    }
    else {
      resolved.event_type = ''
    }

    if (msg.event_object_tag !== undefined) {
      resolved.event_object_tag = msg.event_object_tag;
    }
    else {
      resolved.event_object_tag = ''
    }

    if (msg.event_source !== undefined) {
      resolved.event_source = msg.event_source;
    }
    else {
      resolved.event_source = ''
    }

    if (msg.label !== undefined) {
      resolved.label = msg.label;
    }
    else {
      resolved.label = ''
    }

    return resolved;
    }
};

module.exports = SmaccEvent;
