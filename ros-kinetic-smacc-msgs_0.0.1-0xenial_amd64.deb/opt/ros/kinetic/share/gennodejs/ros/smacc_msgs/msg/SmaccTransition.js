// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SmaccEvent = require('./SmaccEvent.js');

//-----------------------------------------------------------

class SmaccTransition {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.index = null;
      this.transition_name = null;
      this.transition_type = null;
      this.destiny_state_name = null;
      this.source_state_name = null;
      this.history_node = null;
      this.event = null;
    }
    else {
      if (initObj.hasOwnProperty('index')) {
        this.index = initObj.index
      }
      else {
        this.index = 0;
      }
      if (initObj.hasOwnProperty('transition_name')) {
        this.transition_name = initObj.transition_name
      }
      else {
        this.transition_name = '';
      }
      if (initObj.hasOwnProperty('transition_type')) {
        this.transition_type = initObj.transition_type
      }
      else {
        this.transition_type = '';
      }
      if (initObj.hasOwnProperty('destiny_state_name')) {
        this.destiny_state_name = initObj.destiny_state_name
      }
      else {
        this.destiny_state_name = '';
      }
      if (initObj.hasOwnProperty('source_state_name')) {
        this.source_state_name = initObj.source_state_name
      }
      else {
        this.source_state_name = '';
      }
      if (initObj.hasOwnProperty('history_node')) {
        this.history_node = initObj.history_node
      }
      else {
        this.history_node = false;
      }
      if (initObj.hasOwnProperty('event')) {
        this.event = initObj.event
      }
      else {
        this.event = new SmaccEvent();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccTransition
    // Serialize message field [index]
    bufferOffset = _serializer.int32(obj.index, buffer, bufferOffset);
    // Serialize message field [transition_name]
    bufferOffset = _serializer.string(obj.transition_name, buffer, bufferOffset);
    // Serialize message field [transition_type]
    bufferOffset = _serializer.string(obj.transition_type, buffer, bufferOffset);
    // Serialize message field [destiny_state_name]
    bufferOffset = _serializer.string(obj.destiny_state_name, buffer, bufferOffset);
    // Serialize message field [source_state_name]
    bufferOffset = _serializer.string(obj.source_state_name, buffer, bufferOffset);
    // Serialize message field [history_node]
    bufferOffset = _serializer.bool(obj.history_node, buffer, bufferOffset);
    // Serialize message field [event]
    bufferOffset = SmaccEvent.serialize(obj.event, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccTransition
    let len;
    let data = new SmaccTransition(null);
    // Deserialize message field [index]
    data.index = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [transition_name]
    data.transition_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [transition_type]
    data.transition_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [destiny_state_name]
    data.destiny_state_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [source_state_name]
    data.source_state_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [history_node]
    data.history_node = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [event]
    data.event = SmaccEvent.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.transition_name.length;
    length += object.transition_type.length;
    length += object.destiny_state_name.length;
    length += object.source_state_name.length;
    length += SmaccEvent.getMessageSize(object.event);
    return length + 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccTransition';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c2f4d1522a1a2eecc879c6d3683c25b1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 index
    string transition_name
    string transition_type
    string destiny_state_name
    string source_state_name
    bool history_node
    smacc_msgs/SmaccEvent event
    
    ================================================================================
    MSG: smacc_msgs/SmaccEvent
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccTransition(null);
    if (msg.index !== undefined) {
      resolved.index = msg.index;
    }
    else {
      resolved.index = 0
    }

    if (msg.transition_name !== undefined) {
      resolved.transition_name = msg.transition_name;
    }
    else {
      resolved.transition_name = ''
    }

    if (msg.transition_type !== undefined) {
      resolved.transition_type = msg.transition_type;
    }
    else {
      resolved.transition_type = ''
    }

    if (msg.destiny_state_name !== undefined) {
      resolved.destiny_state_name = msg.destiny_state_name;
    }
    else {
      resolved.destiny_state_name = ''
    }

    if (msg.source_state_name !== undefined) {
      resolved.source_state_name = msg.source_state_name;
    }
    else {
      resolved.source_state_name = ''
    }

    if (msg.history_node !== undefined) {
      resolved.history_node = msg.history_node;
    }
    else {
      resolved.history_node = false
    }

    if (msg.event !== undefined) {
      resolved.event = SmaccEvent.Resolve(msg.event)
    }
    else {
      resolved.event = new SmaccEvent()
    }

    return resolved;
    }
};

module.exports = SmaccTransition;
