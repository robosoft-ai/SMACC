// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SmaccTransition = require('./SmaccTransition.js');

//-----------------------------------------------------------

class SmaccTransitionLogEntry {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.transition = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('transition')) {
        this.transition = initObj.transition
      }
      else {
        this.transition = new SmaccTransition();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccTransitionLogEntry
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [transition]
    bufferOffset = SmaccTransition.serialize(obj.transition, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccTransitionLogEntry
    let len;
    let data = new SmaccTransitionLogEntry(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [transition]
    data.transition = SmaccTransition.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += SmaccTransition.getMessageSize(object.transition);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccTransitionLogEntry';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '190a1bfc23c27dba85a0f583d32ff3aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time timestamp
    smacc_msgs/SmaccTransition transition
    ================================================================================
    MSG: smacc_msgs/SmaccTransition
    int32 index
    string transition_name
    string transition_type
    string destiny_state_name
    string source_state_name
    bool history_node
    smacc_msgs/SmaccEvent event
    
    ================================================================================
    MSG: smacc_msgs/SmaccEvent
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccTransitionLogEntry(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.transition !== undefined) {
      resolved.transition = SmaccTransition.Resolve(msg.transition)
    }
    else {
      resolved.transition = new SmaccTransition()
    }

    return resolved;
    }
};

module.exports = SmaccTransitionLogEntry;
