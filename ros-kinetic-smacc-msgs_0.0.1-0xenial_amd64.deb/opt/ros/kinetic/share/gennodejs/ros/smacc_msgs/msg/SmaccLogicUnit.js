// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SmaccEvent = require('./SmaccEvent.js');

//-----------------------------------------------------------

class SmaccLogicUnit {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.index = null;
      this.type_name = null;
      this.object_tag = null;
      this.event_sources = null;
    }
    else {
      if (initObj.hasOwnProperty('index')) {
        this.index = initObj.index
      }
      else {
        this.index = 0;
      }
      if (initObj.hasOwnProperty('type_name')) {
        this.type_name = initObj.type_name
      }
      else {
        this.type_name = '';
      }
      if (initObj.hasOwnProperty('object_tag')) {
        this.object_tag = initObj.object_tag
      }
      else {
        this.object_tag = '';
      }
      if (initObj.hasOwnProperty('event_sources')) {
        this.event_sources = initObj.event_sources
      }
      else {
        this.event_sources = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccLogicUnit
    // Serialize message field [index]
    bufferOffset = _serializer.int32(obj.index, buffer, bufferOffset);
    // Serialize message field [type_name]
    bufferOffset = _serializer.string(obj.type_name, buffer, bufferOffset);
    // Serialize message field [object_tag]
    bufferOffset = _serializer.string(obj.object_tag, buffer, bufferOffset);
    // Serialize message field [event_sources]
    // Serialize the length for message field [event_sources]
    bufferOffset = _serializer.uint32(obj.event_sources.length, buffer, bufferOffset);
    obj.event_sources.forEach((val) => {
      bufferOffset = SmaccEvent.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccLogicUnit
    let len;
    let data = new SmaccLogicUnit(null);
    // Deserialize message field [index]
    data.index = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [type_name]
    data.type_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [object_tag]
    data.object_tag = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [event_sources]
    // Deserialize array length for message field [event_sources]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.event_sources = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.event_sources[i] = SmaccEvent.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.type_name.length;
    length += object.object_tag.length;
    object.event_sources.forEach((val) => {
      length += SmaccEvent.getMessageSize(val);
    });
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccLogicUnit';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5ba6ea3512d5067feaf6be56f6dc5b3c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 index
    string type_name
    string object_tag
    
    smacc_msgs/SmaccEvent[] event_sources
    ================================================================================
    MSG: smacc_msgs/SmaccEvent
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccLogicUnit(null);
    if (msg.index !== undefined) {
      resolved.index = msg.index;
    }
    else {
      resolved.index = 0
    }

    if (msg.type_name !== undefined) {
      resolved.type_name = msg.type_name;
    }
    else {
      resolved.type_name = ''
    }

    if (msg.object_tag !== undefined) {
      resolved.object_tag = msg.object_tag;
    }
    else {
      resolved.object_tag = ''
    }

    if (msg.event_sources !== undefined) {
      resolved.event_sources = new Array(msg.event_sources.length);
      for (let i = 0; i < resolved.event_sources.length; ++i) {
        resolved.event_sources[i] = SmaccEvent.Resolve(msg.event_sources[i]);
      }
    }
    else {
      resolved.event_sources = []
    }

    return resolved;
    }
};

module.exports = SmaccLogicUnit;
