// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SmaccState = require('./SmaccState.js');

//-----------------------------------------------------------

class SmaccStateMachine {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.states = null;
    }
    else {
      if (initObj.hasOwnProperty('states')) {
        this.states = initObj.states
      }
      else {
        this.states = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccStateMachine
    // Serialize message field [states]
    // Serialize the length for message field [states]
    bufferOffset = _serializer.uint32(obj.states.length, buffer, bufferOffset);
    obj.states.forEach((val) => {
      bufferOffset = SmaccState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccStateMachine
    let len;
    let data = new SmaccStateMachine(null);
    // Deserialize message field [states]
    // Deserialize array length for message field [states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.states[i] = SmaccState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.states.forEach((val) => {
      length += SmaccState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccStateMachine';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '98afd3e5f2ced6802af21243f7c69b7d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    smacc_msgs/SmaccState[] states
    ================================================================================
    MSG: smacc_msgs/SmaccState
    int32 index
    string name
    string[] children_states
    int8 level
    smacc_msgs/SmaccTransition[] transitions
    smacc_msgs/SmaccOrthogonal[] orthogonals
    smacc_msgs/SmaccLogicUnit[] logic_units
    
    
    ================================================================================
    MSG: smacc_msgs/SmaccTransition
    int32 index
    string transition_name
    string transition_type
    string destiny_state_name
    string source_state_name
    bool history_node
    smacc_msgs/SmaccEvent event
    
    ================================================================================
    MSG: smacc_msgs/SmaccEvent
    string event_type
    string event_object_tag
    string event_source # the client, substate behavior or component that generated that event
    string label
    
    ================================================================================
    MSG: smacc_msgs/SmaccOrthogonal
    string name
    string[] substate_behavior_names
    string[] client_names
    ================================================================================
    MSG: smacc_msgs/SmaccLogicUnit
    int32 index
    string type_name
    string object_tag
    
    smacc_msgs/SmaccEvent[] event_sources
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccStateMachine(null);
    if (msg.states !== undefined) {
      resolved.states = new Array(msg.states.length);
      for (let i = 0; i < resolved.states.length; ++i) {
        resolved.states[i] = SmaccState.Resolve(msg.states[i]);
      }
    }
    else {
      resolved.states = []
    }

    return resolved;
    }
};

module.exports = SmaccStateMachine;
