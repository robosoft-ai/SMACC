// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class SmaccStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.current_states = null;
      this.global_variable_names = null;
      this.global_variable_values = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('current_states')) {
        this.current_states = initObj.current_states
      }
      else {
        this.current_states = [];
      }
      if (initObj.hasOwnProperty('global_variable_names')) {
        this.global_variable_names = initObj.global_variable_names
      }
      else {
        this.global_variable_names = [];
      }
      if (initObj.hasOwnProperty('global_variable_values')) {
        this.global_variable_values = initObj.global_variable_values
      }
      else {
        this.global_variable_values = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccStatus
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [current_states]
    bufferOffset = _arraySerializer.string(obj.current_states, buffer, bufferOffset, null);
    // Serialize message field [global_variable_names]
    bufferOffset = _arraySerializer.string(obj.global_variable_names, buffer, bufferOffset, null);
    // Serialize message field [global_variable_values]
    bufferOffset = _arraySerializer.string(obj.global_variable_values, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccStatus
    let len;
    let data = new SmaccStatus(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [current_states]
    data.current_states = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [global_variable_names]
    data.global_variable_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [global_variable_values]
    data.global_variable_values = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.current_states.forEach((val) => {
      length += 4 + val.length;
    });
    object.global_variable_names.forEach((val) => {
      length += 4 + val.length;
    });
    object.global_variable_values.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'baf999a5e1691334227c02c7c7f5fbca';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    #returns the list of current states (the complete hierarchy)
    #from ancestor active states to descendents active states), ie: [Superstate1, State3]
    string[] current_states
    
    string[] global_variable_names
    string[] global_variable_values
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccStatus(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.current_states !== undefined) {
      resolved.current_states = msg.current_states;
    }
    else {
      resolved.current_states = []
    }

    if (msg.global_variable_names !== undefined) {
      resolved.global_variable_names = msg.global_variable_names;
    }
    else {
      resolved.global_variable_names = []
    }

    if (msg.global_variable_values !== undefined) {
      resolved.global_variable_values = msg.global_variable_values;
    }
    else {
      resolved.global_variable_values = []
    }

    return resolved;
    }
};

module.exports = SmaccStatus;
