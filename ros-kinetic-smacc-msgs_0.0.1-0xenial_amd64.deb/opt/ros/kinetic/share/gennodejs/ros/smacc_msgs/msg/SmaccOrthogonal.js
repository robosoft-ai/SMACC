// Auto-generated. Do not edit!

// (in-package smacc_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SmaccOrthogonal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.substate_behavior_names = null;
      this.client_names = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('substate_behavior_names')) {
        this.substate_behavior_names = initObj.substate_behavior_names
      }
      else {
        this.substate_behavior_names = [];
      }
      if (initObj.hasOwnProperty('client_names')) {
        this.client_names = initObj.client_names
      }
      else {
        this.client_names = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SmaccOrthogonal
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [substate_behavior_names]
    bufferOffset = _arraySerializer.string(obj.substate_behavior_names, buffer, bufferOffset, null);
    // Serialize message field [client_names]
    bufferOffset = _arraySerializer.string(obj.client_names, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SmaccOrthogonal
    let len;
    let data = new SmaccOrthogonal(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [substate_behavior_names]
    data.substate_behavior_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [client_names]
    data.client_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    object.substate_behavior_names.forEach((val) => {
      length += 4 + val.length;
    });
    object.client_names.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'smacc_msgs/SmaccOrthogonal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a1d4d70a10baa7795e9fddc8c220ead1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string[] substate_behavior_names
    string[] client_names
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SmaccOrthogonal(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.substate_behavior_names !== undefined) {
      resolved.substate_behavior_names = msg.substate_behavior_names;
    }
    else {
      resolved.substate_behavior_names = []
    }

    if (msg.client_names !== undefined) {
      resolved.client_names = msg.client_names;
    }
    else {
      resolved.client_names = []
    }

    return resolved;
    }
};

module.exports = SmaccOrthogonal;
