// Auto-generated. Do not edit!

// (in-package backward_global_planner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class commandRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cmd = null;
    }
    else {
      if (initObj.hasOwnProperty('cmd')) {
        this.cmd = initObj.cmd
      }
      else {
        this.cmd = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type commandRequest
    // Serialize message field [cmd]
    bufferOffset = std_msgs.msg.String.serialize(obj.cmd, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type commandRequest
    let len;
    let data = new commandRequest(null);
    // Deserialize message field [cmd]
    data.cmd = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.cmd);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'backward_global_planner/commandRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '952a146467d5c456d42e02451e4b54fc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String cmd
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new commandRequest(null);
    if (msg.cmd !== undefined) {
      resolved.cmd = std_msgs.msg.String.Resolve(msg.cmd)
    }
    else {
      resolved.cmd = new std_msgs.msg.String()
    }

    return resolved;
    }
};

class commandResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = new std_msgs.msg.Bool();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type commandResponse
    // Serialize message field [result]
    bufferOffset = std_msgs.msg.String.serialize(obj.result, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type commandResponse
    let len;
    let data = new commandResponse(null);
    // Deserialize message field [result]
    data.result = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.result);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'backward_global_planner/commandResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd0800494afb8b2c91f943cf1d38c7b64';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String result
    std_msgs/Bool success
    
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new commandResponse(null);
    if (msg.result !== undefined) {
      resolved.result = std_msgs.msg.String.Resolve(msg.result)
    }
    else {
      resolved.result = new std_msgs.msg.String()
    }

    if (msg.success !== undefined) {
      resolved.success = std_msgs.msg.Bool.Resolve(msg.success)
    }
    else {
      resolved.success = new std_msgs.msg.Bool()
    }

    return resolved;
    }
};

module.exports = {
  Request: commandRequest,
  Response: commandResponse,
  md5sum() { return 'e0d6f2a68e2588b7ee740e1316326494'; },
  datatype() { return 'backward_global_planner/command'; }
};
