
"use strict";

let command = require('./command.js')

module.exports = {
  command: command,
};
